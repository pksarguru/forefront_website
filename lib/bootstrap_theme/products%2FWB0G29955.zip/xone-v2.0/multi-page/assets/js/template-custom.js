
$(function () {
    "use strict";
   //preloader
    $(window).preloader({
        delay:500
    });    
});

